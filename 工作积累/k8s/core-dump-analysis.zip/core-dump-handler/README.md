# core-dump-handler：工程学习与故障排查笔记

> 整理日期：2026-10-22，Asia/Shanghai。面向第一次接触 Linux core dump、Rust 和 Kubernetes 节点采集的读者。
>
> **先记住一句话：Linux 内核生成 core，Composer 接收并打包，Agent 配置节点并上传。Kubernetes 负责把 Agent 部署到节点上。**

这份 Markdown 是本目录的主文档，后续补充优先修改它。HTML 是同一内容的阅读版。之前的专项故障报告与原始证据另行保留，不覆盖。

## 0. 资料范围与阅读路线

### 0.1 我们在讲哪一份工程

- 本地源码：`/Users/liwu.xing/core-dump-handler`。
- 本次逐项阅读的提交：`4d18c344dd04532019769a82321a9a60c34a8ed0`，简称 `4d18c34`。
- 用户提供的部署镜像：`harbor.shopeemobile.com/vespa/core-dump-handler:main-202508251503-5d1ff222`。
- 镜像标签指向的源码提交：`5d1ff222660d865adae51e55aeca5119e03eb1a9`。
- 上述两个提交的差异只有 `.gitlab-ci.yml` 和 `build-docker-image.sh`，Agent、Composer、配置与 libcrio 的相关实现相同。
- **没有读取线上镜像 digest，也没有核对节点上 cdc 的二进制哈希。标签与源码相符，不等于已证明线上二进制完全一致。**

本文区分三种信息：

| 类型 | 表示什么 | 不能推导什么 |
| --- | --- | --- |
| 源码确认 | 指定提交的代码确实这样执行 | 不能证明所有节点都在运行这份代码 |
| 现场证据 | 用户提供的日志、配置、JSON 中确实出现过 | 事后快照不能还原所有历史状态 |
| 原理与建议 | Linux/Kubernetes 官方机制或拟议设计 | 不能当作工程已经具备的功能 |

本次只做源码分析、资料整理与文档验证。**没有编译 Rust、没有运行项目测试、没有构建或推送镜像、没有部署或修改线上节点。** 当前本机 PATH 未发现 `cargo`、`rustc`。

### 0.2 推荐阅读顺序

1. 初次学习：先读第 1～5 节，建立 core、进程、容器和内核之间的关系。
2. 理解工程：读第 6～10 节，跟着一次真实 core 的处理顺序走。
3. 动手开发：读第 11～13 节，了解编译、镜像、Helm 和版本生效。
4. 排查故障：读第 14～17 节，理解本次 `unknown`、重启竞态和验证方法。
5. 回顾与补充：第 18～20 节提供术语、源码索引和待办记录。

### 0.3 本目录归档约定

```text
core-dump-handler/
  README.md                       本学习笔记，后续维护入口
  reports/
    engineering-guide.html        本笔记生成的 HTML
    unknown-root-cause.html        此前交付的专项根因报告
  evidence/
    composer.log                  用户提供的 Composer 日志原文
    332463703.log                  事后节点 CRI 查询结果原文
    crash.zip                     原始压缩包副本
    dump-info.json                已提取的崩溃元数据
    pod-info.json                 已提取的 Pod 元数据，本例为 {}
    archive-manifest.json          原位置、大小、SHA-256 与来源说明
  scripts/
    render_html.py                从 Markdown 生成 HTML
  work/                           文档渲染验证的中间结果
```

未重复复制巨大 `.core` 文件。其原始位置为：

```text
/Users/liwu.xing/480a7491-c248-4a08-a0f4-11681810bf30@unknown@1792653505@unknown@vespa-drsd-bin@8588@6.core
```

**注意敏感性：core 可能包含业务数据、用户内容、密钥或令牌。日志也可能含业务信息。本目录不是可直接公开分享的资料包。**

## 1. core 是什么，为什么需要它

### 1.1 把“程序”和“进程”分开

磁盘上的 `vespa-drsd-bin` 是程序文件；运行起来后，内核为它维护进程、线程、虚拟内存和打开的文件等状态。一个程序文件可以启动很多进程，每次运行状态都可能不同。

日志是程序主动写出的文字。core 则是进程异常终止时，内核按规则导出的进程状态。典型 Linux ELF core 可以包含内存映射、线程寄存器及其他调试信息，供调试器进行事后分析。它不是普通文本，也不是整台机器的内存镜像。参见 [Linux core(5)](https://man7.org/linux/man-pages/man5/core.5.html)。

例如：日志只能告诉你“发生断言失败”；有匹配的 core、可执行文件和调试符号后，可以继续查看当时线程调用栈、局部变量和相关内存。

### 1.2 四种东西不要混为一谈

| 名称 | 内容 | 本工程是否生成/保存 |
| --- | --- | --- |
| 应用日志 | stdout/stderr 等运行记录 | 尝试通过 `crictl logs` 收集尾部日志 |
| 进程 core | 崩溃进程可导出的状态 | 内核生成，Composer 接收 |
| ZIP 包 | core 与若干 JSON、日志的容器 | Composer 创建 |
| 内核 crash dump / vmcore | 内核自身崩溃的取证材料 | 不属于本工程范围 |

“收到了 ZIP”不表示“Pod 信息完整”；“ZIP 能解压”不表示“core 没有截断”；“core 存在”也不表示“已经知道业务崩溃根因”。

### 1.3 哪些退出会产生 core

在常见 Linux/x86-64 环境中，`SIGSEGV` 常与非法内存访问有关，`SIGABRT` 常来自 `abort()` 或失败的断言。这类信号的默认动作可以包含 core dump，但仍受 dumpable 状态、内核配置、权限和采集路径等条件影响。程序也可能设置自己的信号处理逻辑。[signal(7)](https://man7.org/linux/man-pages/man7/signal.7.html)

`SIGKILL` 的默认动作不是生成 core。因此，**不能把 OOM killer 的 SIGKILL、`kill -9`、正常 `exit()` 与会生成 core 的崩溃等同起来**。退出码 137 也不能单独证明“发生了 OOM”；需要结合容器状态与节点日志。

本例参数 `-s=6` 对应此环境中的 `SIGABRT`。它说明终止信号，不足以确定是断言、主动 abort，还是其他触发路径。

### 1.4 core 为什么可能非常大

进程虚拟地址空间、实际驻留内存、导出的 core 逻辑大小、磁盘占用、ZIP 压缩后大小，是不同指标。内核会根据内存映射类别及 `coredump_filter` 等机制决定哪些区域进入 core，不是把整个地址空间无条件复制一遍。[Linux proc 文档](https://docs.kernel.org/filesystems/proc.html)

本例 ZIP 中 core 条目的逻辑大小为 `55,324,082,176` 字节，约 51.52 GiB；原 ZIP 只有约 6.9 MiB。这个差异值得验证，但**既不能仅据此判定损坏，也不能据此证明完整**。本次未完整解压校验，也未用 GDB 分析这个巨大 core。

## 2. 先看总图：谁负责什么

下面的图强调“运行位置”，而不是只按文件夹分组。

```text
Kubernetes 控制面
  Helm 渲染资源 -> DaemonSet 在符合条件的节点部署 Agent Pod
                         |
                         v
节点上的 Agent Pod
  /app/core-dump-agent
    1. 把 cdc、可选 crictl、配置复制到节点可见目录
    2. 设置节点 core_pattern 等 sysctl
    3. 监听/扫描 core 目录并上传 ZIP 到 S3
                         |
                共享节点文件目录
                         |
                         v
宿主机 Linux
  业务进程发生可转储的崩溃
    -> 内核读取 core_pattern
    -> 启动 /data/core-dump-handler/cdc
    -> 内核把 core 字节写到 cdc 的 stdin
    -> cdc 查询本节点 CRI、压缩并写 ZIP
                         |
                         v
  /data/core-dump-handler/cores/*.zip
                         |
                         v
  Agent 上传 -> S3 兼容对象存储 -> 开发者下载分析
```

核心职责只有三个：

| 角色 | 日常语言解释 | 运行时机和位置 |
| --- | --- | --- |
| Linux 内核 | 判断是否转储，生成 core 字节流 | 业务进程崩溃时，节点内核 |
| Composer / `cdc` | 接收 core，补充信息，组成 ZIP | 内核临时启动的节点进程 |
| Agent | 安装处理器、设置节点、上传产物 | DaemonSet 容器内常驻 |

**`cdc` 是 `core-dump-composer` 可执行文件部署后的短名称，不是第三套独立逻辑。**

因此，Agent Pod 正常运行只证明采集基础设施的一部分正常；不证明内核一定触发过 cdc，也不证明每个 ZIP 都成功上传。

## 3. 工程目录与 Rust 入门

### 3.1 从哪些文件开始看

以下路径均相对于源码根目录 `/Users/liwu.xing/core-dump-handler`；第 19 节提供完整绝对路径索引。

| 目录/文件 | 作用 | 建议阅读次序 |
| --- | --- | --- |
| `core-dump-agent/src/main.rs` | 初始化、sysctl、目录监听、S3 上传、卸载 | 1 |
| `core-dump-composer/src/main.rs` | 一次 core 的完整处理过程 | 2 |
| `core-dump-composer/src/config.rs` | 命令参数、`.env`、文件名模板 | 3 |
| `vendor/libcrio/src/lib.rs` | 对 `crictl` 子进程的封装 | 4 |
| Composer 的 `logging.rs` / `events.rs` | 文件日志与可选事件 JSON | 5 |
| `Dockerfile` / `build-docker-image.sh` | 编译、组装镜像、打标签、推送 | 6 |
| `charts/core-dump-handler` | Helm 参数和 Kubernetes 模板 | 7 |
| `vendor/zip` / `vendor/rust-s3-0.31.0` | 随仓库维护的 ZIP / S3 库代码 | 按需 |
| `integration` / 各模块 `tests` | 历史集成脚本与自动测试 | 按需 |

按阅读顺序组织的依赖图如下；箭头表示依赖或调用，不代表全部都在同一进程中：

```mermaid
flowchart TD
    H["1. Helm / DaemonSet"] --> A["2. Agent"]
    A --> K["节点 sysctl / core_pattern"]
    K --> C["3. Composer / cdc"]
    C --> CFG["4. config / logging / events"]
    C --> CRI["5. libcrio -> crictl -> runtime"]
    C --> Z["6. vendor/zip"]
    A --> S["7. vendor/rust-s3 -> S3"]
    classDef start fill:#339af0,color:#fff
    classDef next fill:#9775fa,color:#fff
    classDef later fill:#ced4da,color:#111
    class H,A,C start
    class CFG,CRI next
    class K,Z,S later
```

### 3.2 不懂 Rust，也能先读懂的几种写法

| 写法 | 如何理解 | 在本工程中的意义 |
| --- | --- | --- |
| `fn main()` | 程序入口 | Agent、Composer 各有一个 |
| `Result<T, E>` | 成功得到 T，失败得到 E | 文件、命令、网络等操作会失败 |
| `match result { Ok(v) => ..., Err(e) => ... }` | 分别处理成功和失败 | 有的失败退出，有的失败继续保留 core |
| `operation()?` | 成功继续，失败向调用者返回 | 不是忽略异常 |
| `.unwrap()` | 假定一定有值或成功 | 条件不满足会 panic |
| `json!({})` | 创建空 JSON 对象 | 本例 Pod 查询失败后的降级结果 |
| `Command::new("crictl")` | 启动外部进程 | 并非直接调用 Kubernetes API |
| `async` / `.await` | 异步任务及等待结果 | Agent 的上传和调度使用 Tokio |

仓库顶层 `Cargo.toml` 定义一个 workspace，包含 Agent 和 Composer 两个 package。`Cargo.lock` 记录依赖解析结果；`vendor` 中的若干库通过本地路径依赖或 `[patch.crates-io]` 接入，所以**只看 crates.io 上的同名版本不足以理解此仓库的实际行为**。

本工程没有很厚的业务分层。两个 `main.rs` 承担了大量顺序流程，理解时优先跟着控制流走；不必一开始就读完所有第三方代码。

## 4. Agent 启动时到底做了什么

依据：Agent `main.rs` 44～152、420～500、510～588 行。

### 4.1 启动顺序

1. 读取 Agent 可执行文件同目录的 `.env`（存在时），再从环境变量获取参数。
2. 若参数是 `remove` 或 `sweep`，进入对应分支，不走普通安装流程。
3. 可选生成节点目录下的 `crictl.yaml`。
4. 可选把镜像中的 `crictl` 复制到节点目录。
5. 根据 `VENDOR` 选择并复制 Composer，节点文件名是 `cdc`。
6. 设置 `kernel.core_pattern`、`kernel.core_pipe_limit`、`fs.suid_dumpable`。
7. 将 `COMP_*` 参数转换为 Composer 的 `.env`。
8. 启用上传时，先扫描一次存量文件，再进入定时或 inotify 模式。

### 4.2 镜像内文件与节点文件不是一回事

| 镜像 / Agent 容器内 | 节点部署后 | 用途 |
| --- | --- | --- |
| `/app/core-dump-agent` | 不需要复制到宿主目录 | 常驻服务 |
| `/app/vendor/default/cdc` | `/data/core-dump-handler/cdc` | 内核要执行的处理器 |
| `/app/vendor/rhel7/cdc` | 仍复制为同一个 `cdc` 路径 | 可选兼容构建 |
| `/app/crictl` | `/data/core-dump-handler/crictl` | 可选 CRI 客户端 |
| Agent 环境变量 | `/data/core-dump-handler/.env` | 给独立启动的 cdc 使用 |
| 运行时 endpoint 设置 | `/data/core-dump-handler/crictl.yaml` | 本节点 runtime 的连接配置 |

路径中的 `/data` 来自用户配置；源码默认值是 `/var/mnt/core-dump-handler`。

**内核启动的 cdc 不会自动继承 Agent Pod 的整套环境变量。** 因而需要 Agent 写出的 `.env`。Composer 用 `current_exe()` 找到自己的目录，再加载同目录 `.env`，不是随便从当前工作目录查找。

### 4.3 为什么要 privileged 和节点目录映射

设置节点级 sysctl、向宿主路径部署可执行文件，涉及较高权限。Chart 为 Agent 设置 `privileged: true`，并挂载可与节点共享的目录。这个设计的权限范围很大，不能当普通业务容器部署。[Kubernetes 卷文档](https://kubernetes.io/docs/concepts/storage/volumes/)

当前 Chart 的 PVC 背后模板是 **hostPath PV**。名字叫 PVC 不代表实际一定是远端共享盘；hostPath 的内容属于节点本地路径。用户提供的 DaemonSet 只有 PVC 引用，线上究竟绑定什么 PV，仍需查看实际 PVC/PV。

`mountPropagation: Bidirectional` 处理的是挂载事件传播，不是文件复制工具，不会自动把缺失的 runtime socket 挂进容器。[Kubernetes 卷文档](https://kubernetes.io/docs/concepts/storage/volumes/)

### 4.4 `remove` 与 `sweep` 不要混用

- `remove`：尝试恢复备份的 sysctl，删除部署到节点的文件。Chart 的 `preStop` 会调用它。
- `sweep [文件]`：主动尝试上传指定文件或扫描整个 core 目录，不是纯只读检查。
- 不要在生产节点随手执行无参数 Agent：它会安装处理器并修改节点配置。

当前 `remove()` 依赖 `.bak` 文件存在，部分清理分支还存在 `!exists()` 后才删除的反向判断。这里只说明代码风险，**不能假定卸载一定完整，也不能把卸载当作无副作用的日志查看方式**。

## 5. Linux 如何把 core 交给本工程

### 5.1 `core_pattern` 是入口

用户配置对应的命令模式为：

```text
|/data/core-dump-handler/cdc -c=%c -e=%e -p=%p -s=%s -t=%t -d=/data/core-dump-handler/cores -h=%h -E=%E
```

`core_pattern` 不以 `|` 开头时，通常用于指定 core 文件名模式；以 `|` 开头时，内核将其作为用户态处理器模式，启动程序，并把 core 送入其标准输入。这里不是先生成一个 `.core` 文件，再通知 Agent 去找。[core(5)](https://man7.org/linux/man-pages/man5/core.5.html)

这个 `|` 也不是让交互式 shell 执行一条普通管道命令。参数展开由内核的 core dump 机制处理，不应按 shell 脚本理解。

### 5.2 内核替换哪些参数

| 占位符 | 意义 | 本工程如何用 |
| --- | --- | --- |
| `%c` | 崩溃进程的 core soft resource limit | `-c` 保存参数，不是由 Composer 执行的截断上限 |
| `%e` | 进程/线程的 comm 名称，通常受长度限制且可改变 | `exe_name`，不是可靠的唯一可执行文件身份 |
| `%p` | 崩溃进程在其 PID namespace 中的 PID | 当前 `-p`、文件名中的 pid |
| `%P` | 初始 PID namespace 中的 PID，通常称宿主机 PID | 当前工程没有传入，修复方案拟新增 |
| `%s` | 触发 core 的信号编号 | 例中为 `6` |
| `%t` | Unix Epoch 秒数 | 例中为 `1792653505` |
| `%h` | 崩溃进程所处 UTS namespace 的 hostname | 被当成 Pod 名线索 |
| `%E` | 可执行文件路径，`/` 被编码为 `!` | 例中 `!opt!vespa!sbin!vespa-drsd-bin` |

完整定义见 [Linux core_pattern 文档](https://docs.kernel.org/admin-guide/sysctl/kernel.html#core-pattern)；进程名与路径编码的细节见 [core(5)](https://man7.org/linux/man-pages/man5/core.5.html)。

`-d` 不是内核自动发现的路径，是 Agent 将 `CORE_DIR` 固定写进 pattern 的结果。

对应源码：

<!-- source: core-dump-agent/src/main.rs:113:131 -->
```rust
    copy_core_dump_composer_to_hostdir(host_location)?;
    apply_sysctl(
        "kernel.core_pattern",
        format!("{host_location}/core_pattern.bak").as_str(),
        format!(
            "|{host_location}/{CDC_NAME} -c=%c -e=%e -p=%p -s=%s -t=%t -d={core_dir_command} -h=%h -E=%E")
        .as_str(),
    )?;
    apply_sysctl(
        "kernel.core_pipe_limit",
        format!("{host_location}/core_pipe_limit.bak").as_str(),
        "128",
    )?;

    apply_sysctl(
        "fs.suid_dumpable",
        format!("{host_location}/suid_dumpable.bak").as_str(),
        &suid,
    )?;
```

### 5.3 为什么容器里的 PID 不能直接用于节点 `/proc`

Linux namespace 为进程提供不同的资源视图。PID namespace 改变可见 PID，UTS namespace 改变 hostname 视图，mount namespace 改变路径/挂载视图。[namespaces(7)](https://man7.org/linux/man-pages/man7/namespaces.7.html)

```text
同一个业务进程：
  容器内可能看到 PID 8588
  节点上可能看到 PID 317204

8588 来自本例的 %p。
317204 只是示意数字，不是本例已查明的宿主机 PID。
```

内核的管道 core handler 在初始 namespaces 中运行，不能把 `%p` 无条件用于宿主机 `/proc/<pid>`。需要该视图下的 `%P`。本工程 JSON 字段名虽叫 `real_pid`，实际写入的仍是 `%p`。[core(5)](https://man7.org/linux/man-pages/man5/core.5.html)

### 5.4 `core_pipe_limit=128` 不表示 128 MB

它限制同时处理的管道式 core dump 数量。非零值还让内核等待收集器退出，以避免过早回收崩溃进程的 `/proc` 信息；超过限制的 dump 会被跳过。值为 0 时没有该等待保证。[Linux kernel sysctl 文档](https://docs.kernel.org/admin-guide/sysctl/kernel.html)

工程写入 128，但**实际节点值未取证**。它也不保证权限允许读取 `/proc`，更不保证 CRI 元数据永远不会被清理。

### 5.5 `ulimit -c`、dumpable 与 `suid_dumpable`

- `ulimit -c` 是 shell 对进程 core 资源限制的接口，通常影响子进程，不会追溯修改已经运行的业务进程。
- 对内核直接写文件和对管道 handler，不能照搬同一条限制规则。Linux 管道式 core 路径不按 `RLIMIT_CORE` 限制 core 大小；不能见到 `ulimit -c 0` 就直接判定本工程必然收不到 core。[core(5)](https://man7.org/linux/man-pages/man5/core.5.html)
- 进程的 dumpable 状态仍然重要。`PR_SET_DUMPABLE` 可改变这一属性；部分权限/凭证变化也会影响它。[PR_SET_DUMPABLE](https://man7.org/linux/man-pages/man2/PR_SET_DUMPABLE.2const.html)
- `fs.suid_dumpable=2` 主要关系到通常因安全原因不允许转储的特权进程及其安全输出要求，不是“打开所有 core”的万能开关。它是节点安全策略，应与原策略一起审查。[Linux fs sysctl 文档](https://docs.kernel.org/admin-guide/sysctl/fs.html)

### 5.6 与 systemd-coredump 的关系

一个节点的 `core_pattern` 是共享入口，不能同时独立指向两套互不知情的处理器。安装本工程可能替换原先的 `systemd-coredump` 或其他采集器；因此 `coredumpctl` 中没有记录，不能直接证明本工程没有收到 core。先确认实际 pattern 指向谁。

## 6. Composer 如何接收、压缩与打包

依据：Composer `main.rs` 26～387 行、`config.rs`。

### 6.1 真正的执行顺序

1. 解析内核参数，生成一次性 UUID，读取同目录 `.env`。
2. 初始化同目录 `composer.log`。
3. 先调用 `cli.pod(hostname)`，尝试得到 Pod sandbox 的基本信息。
4. 查询失败时得到 `{}`；namespace、podname 回退成 `unknown`。
5. 若配置标签过滤，检查已查询结果是否含该 label key。
6. 根据模板决定 ZIP 和各条目文件名，创建并锁定 ZIP。
7. 写入 `dump-info.json`。
8. **从 stdin 流式读取 core，直接写入 ZIP 条目。**
9. 如果 `IGNORE_CRIO=true`，完成较简化的打包分支并退出。
10. 否则写 `pod-info.json`，获取 sandbox ID。
11. 继续查 `inspectp`、容器列表、各容器尾日志和镜像信息，写进 ZIP。
12. 完成 ZIP、解锁；可选发送 webhook、写事件 JSON。

**步骤 3 在大 core 写入之前；步骤 11 在大 core 写入之后。** 后半段仍会查询当时的 runtime 状态，因此存在生命周期变化带来的竞态。

### 6.2 core 字节究竟从哪里来

<!-- source: core-dump-composer/src/main.rs:170:180 -->
```rust
    let stdin = io::stdin();
    let mut stdin = stdin.lock();

    match io::copy(&mut stdin, &mut zip) {
        Ok(v) => v,
        Err(e) => {
            error!("Error writing core file \n{}", e);
            process::exit(1);
        }
    };
    zip.flush()?;
```

它没有执行 `gcore`，没有连接 GDB，也没有扫描业务目录寻找 core。`io::copy` 读到的正是内核接到 stdin 的字节流。

流式处理意味着不必先把几十 GiB 的 core 全部读入一个内存数组。但压缩、缓冲、内核管道和后续上传仍消耗资源，不能理解成“零内存”或“零 CPU”。

### 6.3 这个 ZIP 用了什么压缩

<!-- source: core-dump-composer/src/main.rs:117:127 -->
```rust
    // Create the base zip file that we are going to put everything into
    let compression_method = if cc.compression {
        zip::CompressionMethod::Zstd
    } else {
        zip::CompressionMethod::Stored
    };
    let options = FileOptions::default()
        .compression_method(compression_method)
        .compression_level(Option::from(1))
        .unix_permissions(0o444)
        .large_file(true);
```

- 开启压缩：ZIP 条目使用 **Zstandard，级别 1**，不是某些旧文档描述的 Deflate。
- 关闭压缩：仍生成 ZIP 容器，但条目以 Stored 方式存放，不等于不打包。
- `large_file(true)` 启用大文件相关 ZIP64 支持，适应超出传统 ZIP 尺寸范围的条目。
- `0o444` 是归档条目的 Unix 权限元数据，不等于磁盘上的 ZIP 本身已经只读或加密。

老版 `unzip` 可能不支持 ZIP 中的 Zstandard。看到“不支持压缩方法”要先核对解压器能力，不能立刻判定包坏了。7-Zip 的历史说明记录了 ZIP/ZSTD 支持的引入，使用时仍应确认实际工具版本。[7-Zip 版本历史](https://www.7-zip.org/history.txt)

### 6.4 正常包中有什么

下面以 `<base>` 表示模板生成的长文件名，不是需要原样输入的字符串。

| ZIP 条目 | 来自哪里 | 帮助回答什么 |
| --- | --- | --- |
| `<base>.core` | 内核 stdin | 崩溃时的进程状态 |
| `<base>-dump-info.json` | 内核参数与 Composer 配置 | 时间、信号、hostname、节点、路径 |
| `<base>-pod-info.json` | `crictl pods` 中选中的条目 | namespace、name、UID、sandbox ID、labels |
| `<base>-runtime-info.json` | `crictl inspectp` | sandbox 的运行时详情 |
| `<base>-ps-info.json` | `crictl ps -p` | 当时枚举到的容器 |
| `<base>-0.log` 等 | `crictl logs --tail` | 某个容器的尾部日志 |
| `<base>-0-image-info.json` 等 | runtime 镜像列表匹配 | 镜像标识、tags、digests |

镜像 JSON 不是镜像 tar，也不包含业务可执行文件和完整根文件系统。容器列表可能有多个容器；编号 0 不表示它必然就是发生崩溃的容器。

### 6.5 锁和超时分别解决什么

Composer 对 ZIP 持有排他文件锁；Agent 上传前尝试获取共享锁，以避免读取仍被协作写入的文件。这里是协作机制，不是“文件被锁就谁都无法读取”。[Rust File 文件锁文档](https://doc.rust-lang.org/std/fs/struct.File.html#method.lock)

Composer 主线程等待工作线程，超时会 `exit(32)`。用户配置的 `COMP_TIMEOUT=3600` 是 **3600 秒**；代码默认值是 600 秒。超时可能发生在 CRI 查询、core 写入或其他处理阶段，不能只理解为“上传超时”，因为 S3 上传在另一个进程中。

超时或异常退出会释放文件句柄，但 ZIP 可能没写完中央目录。**文件关闭不是业务成功标志。** Agent 没有把 Composer 的退出状态或“完整成功标记”作为上传前置条件。

## 7. 如何从 hostname 找到 Pod 信息

依据：`vendor/libcrio/src/lib.rs` 94～115、133～164、183～221、270～276 行。

### 7.1 `crictl`、CRI、containerd 是什么关系

```text
Composer
  -> libcrio（Rust 封装）
  -> crictl（命令行客户端）
  -> Unix socket
  -> containerd 的 CRI 服务
  -> 本节点 Pod sandbox / container / image 元数据
```

CRI 是容器运行时接口。`crictl` 面向这个接口，不是 `kubectl` 的另一种拼法。`kubectl` 查询 Kubernetes API；本工程的这条路径查询的是**本节点 runtime**。[Kubernetes crictl 文档](https://kubernetes.io/docs/tasks/debug/debug-cluster/crictl/)

名字 `libcrio`、变量 `CRIO_ENDPOINT` 是工程历史命名，不表示只能使用 CRI-O。用户配置连接的是 containerd socket。

### 7.2 Pod 名、UID、sandbox ID、container ID

| 标识 | 表示什么 | 是否可互换 |
| --- | --- | --- |
| namespace + Pod name | Kubernetes 中某时刻的名称定位 | 删除重建后可以复用 |
| Pod UID | 一次 Pod 对象实例身份 | 不是 sandbox ID |
| sandbox ID | runtime 管理的一次 Pod sandbox 实例 | `crictl inspectp` 使用 |
| container ID | 一次容器运行实例 | `crictl inspect`、`logs` 等使用 |
| PID | 内核进程编号，还依赖 PID namespace | 不是 Pod ID |

CRI 定义中，PodSandbox metadata 有 name、namespace、UID；容器列表记录包含 `pod_sandbox_id`。它们可以建立关联，但不能把一个字段当成另一个。[CRI API 定义](https://github.com/kubernetes/cri-api/blob/master/pkg/apis/runtime/v1/api.proto)

### 7.3 当前代码不是通过 PID 查 Pod

配置 `USE_CRIO_CONF=true` 时，代码把 hostname 按点切开，取第一段用于：

```bash
# 执行位置：故障节点。只读查询。
/data/core-dump-handler/crictl \
  -c /data/core-dump-handler/crictl.yaml \
  pods --name services-drs-2-0 -o json
```

- `-c` 指定配置文件。
- `pods` 枚举 runtime 的 Pod sandbox 记录。
- `--name` 是名称过滤，不提供 namespace 身份保证；该版本 CLI 的名称匹配还是正则语义，不应视为严格唯一键。
- `-o json` 输出机器可解析的 JSON。

`crictl` 版本 1.22 的过滤实现可对照 [cri-tools v1.22.0 源码](https://github.com/kubernetes-sigs/cri-tools/blob/v1.22.0/cmd/crictl/sandbox.go)。

### 7.4 多候选时如何选择

<!-- source: vendor/libcrio/src/lib.rs:94:115 -->
```rust
    pub fn pod(&self, hostname: &str) -> Result<Value, String> {
        let names = hostname.split(".").map(str::to_string).collect::<Vec<String>>();
        let pod_output_args = match &self.config_path {
            Some(s) => {
                vec!["-c", s.as_str(), "pods", "--name", &names[0], "-o", "json"]
            }
            None => {
                vec!["pods", "--name", hostname, "-o", "json"]
            }
        };
        let output = run_command(pod_output_args, &self.bin_path)?;
        let items = output["items"].as_array().unwrap();
        if items.is_empty() {
            return Err("failed to create pod".to_string());
        } else if items.len() == 1 {
            return Ok(items[0].clone());
        }
        return items.iter().find(|item| {
            names.iter().skip(1).last().map(String::as_str).unwrap_or("") ==
                item["metadata"]["namespace"].as_str().unwrap_or("")
        }).cloned().ok_or("failed to find pod".to_string());
    }
```

用普通语言翻译：

1. 没有候选：报 `failed to create pod`。这个错误文案容易误解，代码实际上没有创建 Pod。
2. 恰好一个候选：直接采用。
3. 多个候选：取 hostname 第一段之后的最后一段作为 namespace 线索，再匹配。
4. 线索为空或匹配不上：报 `failed to find pod`。

默认 Pod hostname 通常来自 Pod name，但也可以由 Pod 配置改变；hostname 不是 namespace/UID 的通用替代物。[Pod hostname 文档](https://kubernetes.io/docs/concepts/workloads/pods/pod-hostname/)

Composer 会先尝试剥掉 `.svc.<search>` 或 `.<search>` 后缀；这仍不能凭空补出短 hostname 中不存在的 namespace。简单把普通 DNS 域名最后一段当 namespace，也不是通用可靠设计。

### 7.5 两个看似能绕过、实际上不能的设置

**`COMP_POD_SELECTOR_LABEL` 不是 Kubernetes label selector 表达式。** 当前实现是在 Pod 查询结束之后，检查选中对象是否包含某个 label key，不匹配值。它不能先过滤歧义候选；若查询失败得到 `{}`，后面的 `as_object().unwrap()` 还有 panic 风险。

**`COMP_IGNORE_CRIO=true` 也不会跳过最前面的 `cli.pod()`。** 判断位置在 core 写入之后，只跳过后续补充信息阶段。因此它不能被解释成“完全不调用 CRI”。

## 8. Agent 如何发现并上传 ZIP

依据：Agent `main.rs` 136～284、289～418 行；本地 S3 库 `bucket.rs` 51、850～923 行。

### 8.1 三种上传模式

| 模式 | 参数 | 实际行为 |
| --- | --- | --- |
| inotify | `USE_INOTIFY=true` | 监听 core 目录的关闭事件，处理 `CLOSE_WRITE` |
| 定时扫描 | `SCHEDULE` 或 `INTERVAL` | 周期扫描目录文件 |
| 不自动上传 | 三者均未启用 | Agent 等待，文件留在节点 |

用户配置使用 inotify。启用任一种上传时，Agent 启动后先扫描一次存量文件。定时分支优先于 inotify；`INTERVAL` 非空时会转换为 schedule，优先于原来的 `SCHEDULE`。

这里的 inotify 监听的是**Composer 写文件的事件**，不是监听业务进程崩溃的信号。崩溃触发点仍是内核。

纯 inotify 模式没有一个独立周期重试循环：某次网络上传失败后文件保留，但不保证会再次产生关闭写入事件。因此重试可能依赖后续 `sweep`、Agent 重启时扫描等行为。

### 8.2 上传顺序

```text
发现文件
  -> 打开文件
  -> 尝试共享锁
  -> 构造 S3 bucket/client
  -> put_object_stream(file, 文件 basename)
  -> 若库返回 Err：记日志，保留本地文件
  -> 若库返回 Ok：删除本地文件，记录返回码
```

Agent 扫描目录时没有只允许 `.zip` 的后缀过滤。不要把随手写的日志、标记文件、测试数据放在这个上传目录里。

### 8.3 100 MiB 分块与上传成功边界

当前 vendored S3 库的 `CHUNK_SIZE` 为 `104_857_600` 字节，即 100 MiB。小文件走普通 PUT，大文件走 multipart；它不是每次把整个大 ZIP 都装进内存。

但阅读成功路径时必须注意：

- Agent 以库返回 `Ok` 作为删除本地文件的条件。
- vendored multipart 路径中，上传 part 和 complete 请求的返回码在相关位置被忽略；最后返回的是前面 initiate 请求的 `code`。
- 默认特性没有启用 `fail-on-err`；不能把每一个 HTTP 错误都假定会自动转换为 `Err`。

这是**源码确认的可靠性风险，不是本次 unknown 的已证实原因**。验收应验证远端对象确实存在、大小一致、可完整读取，不能只看一行 `S3 Returned: 200`。

### 8.4 资源限制的边界

DaemonSet 配置的 CPU/内存 request/limit 约束 Agent 容器。内核另外启动的宿主机 cdc 不能直接假定属于该 Pod 的资源 cgroup；实际资源归属要查节点进程。压缩很多大 core 会消耗节点 CPU、I/O 和存储，128 个并发处理名额也不等于节点一定承受得住。

hostPath PV 的声明容量不是自动生效的目录磁盘配额。需要监控实际文件系统空间、inode、core 积压和上传失败。

## 9. 通知、事件、日志是三条不同链路

### 9.1 webhook 通知不等于上传完成

Composer 正常完成 ZIP 后，如果 `NOTIFY_N8N_URL` 非空，会发一个 HTTP POST：

```json
{
  "Key": "coredump_alert/<生成的文件名>.zip"
}
```

超时设置是 10 秒。代码调用 `.send()?`，没有调用 `error_for_status()`；网络错误与 HTTP 4xx/5xx 的处理不能混为一谈。

**这段通知在 Composer 中，而 S3 上传在 Agent 中，二者不是同一条“上传后通知”事务。** 通知发出时，文件可能尚未上传完成；本例因缺少 pod ID 提前退出，也到不了这段通知逻辑。

通知代码自行拼接 `coredump_alert/` 前缀；Agent 上传参数则是文件 basename。外部 webhook、bucket 或网关是否做路径映射未核实，不能用通知字段直接推断最终 S3 key。

### 9.2 `CORE_EVENTS` 写的是文件

开启 `CORE_EVENTS` 时，Composer 的 `events.rs` 会写 `<UUID>-event.json` 到事件目录。当前所读代码没有在这里直接调用 Kubernetes API 创建 Event。

因此 Chart 中存在创建 Kubernetes Event 的 RBAC 权限，不意味着本工程已实际向 API Server 上报了这个事件。用户现场配置 `COMP_CORE_EVENTS=false`，这个分支没有开启。

### 9.3 三种日志分别看哪里

| 日志 | 产生者 | 入口 |
| --- | --- | --- |
| Agent 日志 | DaemonSet 容器内 Agent | `kubectl logs` |
| Composer 日志 | 宿主机 cdc | cdc 同目录的 `composer.log` |
| ZIP 内业务日志 | 被采集的业务容器 | `crictl logs` 后写入 ZIP |

用户配置 `HOST_DIR=/data/core-dump-handler`，所以现场已确认的 Composer 日志是：

```text
/data/core-dump-handler/composer.log
```

不是默认示例里的 `/var/mnt/core-dump-handler/composer.log`。`COMP_LOG_LENGTH=500` 控制被采集业务日志的尾行数，**不是 Composer 日志最多保留 500 行**。当前 FileAppender 没有配置日志轮转。

并发 cdc 会写同一日志文件；排查时同时对齐时间、UUID、参数和节点，不能把相邻日志块自动当成同一个故障。

## 10. 用户这份配置如何流到代码里

### 10.1 配置分成四层

```text
Helm values / 实际 DaemonSet YAML
  -> Agent Pod 环境变量
  -> 节点上的 cdc、.env、crictl.yaml 和 sysctl
  -> 每次新启动的 Composer 读取
```

修改 values 或 DaemonSet 模板不等于所有节点立即生效。还要确认 Pod 是否重建、Agent 是否重新部署宿主文件、实际 `core_pattern` 是否指向正确二进制。

### 10.2 本例参数速查

| Agent 环境变量 | 用户配置 | 后续作用 |
| --- | --- | --- |
| `HOST_DIR` | `/data/core-dump-handler` | cdc、配置、日志位置 |
| `CORE_DIR` | `/data/core-dump-handler/cores` | 写入 pattern 的输出目录、Agent 监控目录 |
| `DEPLOY_CRIO_CONFIG` | `true` | 生成 `crictl.yaml`；Composer 的 `USE_CRIO_CONF=true` |
| `DEPLOY_CRIO_EXE` | `true` | 复制镜像携带的 crictl |
| `CRIO_ENDPOINT` | `unix:///run/containerd/containerd.sock` | 节点 runtime endpoint |
| `VENDOR` | `default` | 使用默认 UBI8 构建的 cdc |
| `COMP_FILENAME_TEMPLATE` | UUID/ns/time/pod/exe/pid/signal | `.env` 中 `FILENAME_TEMPLATE` |
| `COMP_LOG_LEVEL` | `Debug` | Composer 文件日志级别，不是 Agent 的日志级别 |
| `COMP_LOG_LENGTH` | `500` | 每个枚举到的容器尾部日志行数 |
| `COMP_TIMEOUT` | `3600` | Composer 处理等待超时秒数 |
| `COMP_COMPRESSION` | `true` | Zstandard ZIP 条目 |
| `COMP_IGNORE_CRIO` | `false` | 不跳过后半段 CRI 补充信息 |
| `COMP_POD_SELECTOR_LABEL` | 空 | 不启用标签 key 检查 |
| `COMP_CORE_EVENTS` | `false` | 不写 CoreEvent 文件 |
| `COMP_NOTIFY_N8N_URL` | 已配置，本文不复述地址 | 正常完成 ZIP 后尝试通知 |
| `USE_INOTIFY` | `true` | 关闭写入事件触发上传 |
| `INTERVAL` / `SCHEDULE` | 空 | 未启用周期扫描 |
| `S3_*` | 部分来自 Secret | 只给上传链路使用，不把密钥写入笔记 |

Agent 生成的 `crictl.yaml` 还硬编码了 `timeout: 2`。这与 `COMP_TIMEOUT=3600` 是两个不同层次的超时。

### 10.3 需要额外确认的部署事实

- 用户 DaemonSet 是 `OnDelete`：模板更新不会自动替换旧 Pod。[DaemonSet 更新文档](https://kubernetes.io/docs/tasks/manage-daemon/update-daemon-set/)
- `imagePullPolicy: Always` 是容器启动时的拉取策略，不会让正在运行的容器热更新。
- 用户配置没有挂载 containerd socket 到 Agent 容器。节点上 cdc 可访问 socket，不等于在 Agent 容器里执行同一条 crictl 命令也能访问。
- YAML 中的零值 `status`、`creationTimestamp: null` 不能据此断言线上没有 Pod；它可能是编辑器导出或提交体，需要实际 API 查询。
- 本例有 `postStart: mkdir -p ...`；仓库当前 Chart 的 DaemonSet 模板没有同样的 postStart。部署实物与模板需要分开比较。

## 11. 怎么编译：先理解产物，再执行命令

### 11.1 这个工程优先在 Linux 环境构建

Agent 使用 Linux 的 inotify 等能力，Composer 运行在 Linux 节点。不要把 macOS 上能编译一个文件，等同于已经得到可在生产节点运行的二进制。

当前代码使用标准库 `File::lock`、`try_lock_shared`、`unlock`，这些 API 在 Rust 1.89.0 稳定；因此**至少这部分代码要求 Rust 1.89.0 或更新，依赖项还可能提出额外要求**。这不是从老 README 推断的工具链版本。[Rust File 文档](https://doc.rust-lang.org/std/fs/struct.File.html#method.lock)

主 Dockerfile 通过 rustup 安装构建时的默认 stable，没有固定工具链版本。旧 `musl.Dockerfile` 的 arm64 路径却固定 Rust 1.61.0，与当前代码存在明显不匹配，不能直接假定可构建。

### 11.2 这些 Cargo 概念是什么意思

| 概念 | 含义 |
| --- | --- |
| `cargo build` | 构建调试版本 |
| `--release` | 使用 release profile，通常有优化 |
| `-p core-dump-composer` | 只选 workspace 中的 Composer package |
| `--locked` | 要求沿用锁文件，不允许悄悄修改依赖解析 |
| `target/release/` | 常见 release 输出目录 |

本仓库 release profile 设置 `debug=true`、`panic="abort"`：保留调试信息，并在 panic 时选择 abort 策略；它不代表业务程序的编译参数也自动改变。[Cargo build 文档](https://doc.rust-lang.org/cargo/commands/cargo-build.html)

### 11.3 编译命令示例

以下是**准备好的 Linux 开发机/构建容器内**执行的示例，本次未实际运行：

```bash
# 执行位置：Linux 上的源码根目录。会写 target/，可能下载依赖。
cargo build --release --locked

# 或仅构建 Composer
cargo build --release --locked -p core-dump-composer
```

产物是两个二进制：

```text
target/release/core-dump-agent
target/release/core-dump-composer
```

单纯编译成功不会自动安装到节点，也不会自动修改 `core_pattern`。**不要为了“试一下”直接在生产节点启动 Agent 二进制。**

### 11.4 测试与真实内核验证是两回事

Composer 测试使用保存的 `mocks/test.core` 作为 stdin，再用 shell 脚本冒充 crictl。它验证打包、配置、错误路径等，不需要真的让业务进程崩溃。

模块 README 明确要求在 Composer 目录执行，并使用单线程，因为测试共享/替换 mock crictl：

```bash
# 执行位置：Linux 开发环境中的源码根目录。
cd core-dump-composer
cargo test --locked -- --test-threads=1
```

若此前失败留下 `output/`，先检查内容并保存证据，再按模块说明清理测试产物；不要把删除命令套到真实 core 目录。

更一般的检查命令：

```bash
# 执行位置：源码根目录。仅示例，未执行。
cargo fmt --all -- --check
cargo clippy --all-targets -- -D warnings
```

当前仓库存在历史测试与实现可能不同步的迹象，例如 Agent 测试仍断言 `.env` 行数为 11，而实现已写入更多配置项。不能在没有执行结果的情况下写“测试已通过”。GitHub CI 的执行目录也不能替代模块 README 的具体约束。

## 12. Docker 镜像怎么打出来

### 12.1 主 Dockerfile 是多阶段构建

```text
阶段一：UBI7 构建环境
  安装 GCC / OpenSSL 开发依赖 / Rust
  cargo build --release -p core-dump-composer
  -> 较旧系统环境构建的 Composer

阶段二：UBI8 构建环境
  安装 GCC / OpenSSL 开发依赖 / Rust
  cargo build --release
  下载 crictl v1.22.0 linux-amd64
  -> Agent + 默认 Composer + crictl

阶段三：UBI8 minimal 运行镜像
  安装 procps-ng 等运行工具
  只复制两个阶段的必要二进制
  CMD 启动 core-dump-agent
```

多阶段构建把“编译工具箱”与“最终运行环境”分开，不需要把完整 Rust 编译器和源码都塞进最终运行镜像。[Docker 多阶段构建文档](https://docs.docker.com/build/building/multi-stage/)

最终镜像布局：

```text
/app/
  core-dump-agent
  crictl
  vendor/
    default/cdc
    rhel7/cdc
```

### 12.2 为什么要编译两份 cdc

Agent 留在镜像中运行；cdc 被复制到宿主机运行。宿主机的 CPU 架构、动态链接器、glibc/OpenSSL 等可用库可能与 Agent 镜像不同。因此“镜像能启动”不等于“复制出去的 cdc 一定能启动”。

`VENDOR=rhel7` 选择第一阶段产物，`default` 选择 UBI8 产物。这是兼容性策略，不是对所有 Linux 发行版的保证。部署前应在目标节点检查架构、`file cdc`、必要库和实际执行结果。

主 Dockerfile 下载的是固定 **linux-amd64** 的 crictl，不能直接把默认构建解释成完整多架构支持。仓库另有 musl 构建流程，但其基础镜像、工具链和 TLS 依赖都需要重新验证。

### 12.3 手工构建与仓库脚本

```bash
# 执行位置：具备 Docker 的开发/构建机，源码根目录。
# 示例命令会构建本地镜像，不部署、不推送。
docker build --platform=linux/amd64 \
  -t core-dump-handler:learning .
```

在非 amd64 主机上可能需要构建器模拟支持；主 Dockerfile 的旧基础镜像和实时安装 stable 工具链，也可能遇到构建兼容性问题。这是命令示例，不是本次成功构建记录。

仓库 `build-docker-image.sh` 的行为：

1. 拼接 Harbor 仓库地址。
2. CI 模式标签为 `分支-时间戳-短SHA`，非 CI 为 `分支-短SHA`。
3. 执行 `docker build --network host`。
4. 只要 `PUSH_IMAGE` **非空**就推送；设为 `"false"` 仍会推送。
5. 最后执行 `docker image rm`，移除对应本地镜像标签。

所以学习时需要保留本地镜像，直接 `docker build` 更容易理解。不要以为执行脚本一定只构建、不推送、不删除本地标签。

### 12.4 GitLab、GitHub 与 Helm 包各做什么

当前 GitLab CI：

- build job 的规则是 Web 手动触发；登录 Harbor，设置 `PUSH_IMAGE=1`，运行构建脚本。
- 脚本把标签写入 CI `.env` artifact，供后续阶段读取。
- 当前 HEAD 新增 cosign 签名阶段，用组织的签名工具签镜像。
- build 与签名 job 的 rules 不完全一致，不能笼统称“每次 push 都完整构建、签名成功”。

镜像标签 `main-202508251503-5d1ff222` 可读作 main 分支、构建脚本产生的日期时间段、源码短 SHA。时间取决于 CI runner 的时区；不能仅从标签推断为北京时间。该标签对应的提交早于当前新增签名阶段，不能反推它已经签名。

仓库 `.github/workflows` 保留历史测试、Chart 发布和 musl 镜像流程。文件存在不证明它们仍在内部 GitLab 环境中执行。

**镜像包与 Helm Chart 包不同：**

- 镜像装的是运行文件，推送到镜像仓库。
- Chart 装的是 Kubernetes YAML 模板、默认参数等，部署时再引用镜像。
- 本地已有 `chart.tar.gz` 是原有未跟踪文件，本次没有修改，也没有把它当作已验证发布包。

## 13. Helm 怎么部署，怎么证明版本真的生效

### 13.1 Chart 主要创建哪些资源

DaemonSet、ServiceAccount、ClusterRole/Binding、host/core 的 PV/PVC，以及按配置启用的 Secret、事件卷和特定平台资源。DaemonSet 在**符合调度条件**的节点上部署 Pod，不是无条件覆盖所有节点。

Chart 的默认 `image.tag` 与 Cargo package 版本本身就不同；版本字段只是不同层面的元信息。发布时应记录镜像 digest、源码 SHA、Chart 版本和渲染参数，而非只记“8.x”。

### 13.2 先渲染检查，不要直接对生产试装

```bash
# 执行位置：有 Helm 的开发机，源码根目录。
# 先准备并审核自己的 values-learning.yaml。
helm lint ./charts/core-dump-handler -f values-learning.yaml

# 仅渲染，不提交给 Kubernetes。
helm template core-dump-handler ./charts/core-dump-handler \
  --namespace core-dump-handler \
  -f values-learning.yaml

# 打包 Chart，不会构建镜像或部署节点。
helm package ./charts/core-dump-handler --destination /tmp
```

这是流程示例；`values-learning.yaml` 不是仓库已存在文件。不要把生产 S3 密钥或 webhook 凭证写进可提交的 values 文件。

只展示非敏感设置的覆盖示例：

```yaml
image:
  registry: your-approved-registry
  repository: your-team/core-dump-handler
  tag: your-reviewed-tag

daemonset:
  hostDirectory: /data/core-dump-handler
  coreDirectory: /data/core-dump-handler/cores
  eventDirectory: /data/core-dump-handler/events
  vendor: default
  deployCrioConfig: true
  includeCrioExe: true
  crioEndpoint: unix:///run/containerd/containerd.sock
  useINotify: true
  updateStrategy:
    type: OnDelete

composer:
  logLevel: Debug
  timeout: 3600
  compression: true
  notifyN8nUrl: ""
```

**这不是完整、可直接上线的部署配置。** 镜像、Secret/IAM、存储、调度、安全策略、S3 bucket/endpoint、网络与旧采集器迁移，都要补齐并审核。默认 Chart 还含较旧的 PSP 相关配置，不能只凭早年兼容列表判断对当前集群的兼容性。

### 13.3 验收链路比 Pod Ready 更长

```text
源码提交
 -> CI 构建与测试
 -> 镜像 digest / 签名
 -> 审核后的 Helm 渲染结果
 -> 目标节点上的新 Agent Pod
 -> 节点 cdc 与配置已部署
 -> 实际 sysctl 已生效
 -> 隔离测试进程产生 core
 -> 包内身份与内容正确
 -> 远端对象可读取、可校验
```

`OnDelete` 更新需要受控重建目标 Pod 才应用新模板。重建还会涉及 `preStop remove`、sysctl 恢复和新 Agent 初始化，可能出现采集窗口；不能把整个 DaemonSet 的重启当无风险操作。

## 14. 本次 unknown 故障复盘

### 14.1 已有证据

| 项目 | 内容 |
| --- | --- |
| 主 core UUID | `480a7491-c248-4a08-a0f4-11681810bf30` |
| 崩溃参数时间 | 2026-10-22 15:18:25，北京时间 |
| 内核传入 hostname | `services-drs-2-0` |
| 节点 | `10.137.20.1` |
| 内核传入 `%p` | `8588`，不能直接当宿主 PID |
| 信号 | `6`，本环境中的 SIGABRT |
| 首个归属错误 | `failed to find pod` |
| 归属降级 | `pod_object={}`；namespace、podname 都为 `unknown` |
| 后续错误 | `Failed to get pod id` |

生成文件名：

```text
480a7491-c248-4a08-a0f4-11681810bf30@unknown@1792653505@unknown@vespa-drsd-bin@8588@6.zip
```

### 14.2 按时间看因果，而不是只看最后一行

| 北京时间 | 发生的事情 | 如何理解 |
| --- | --- | --- |
| 15:18:25.379149 | cdc 收到参数 | 内核已触发采集 |
| 15:18:25.379239 | 按 hostname 调 `crictl pods` | 开始归属判断 |
| 15:18:25.399888 | `failed to find pod` | 多候选分支未匹配到 namespace |
| 15:18:25.399993 | 创建含 unknown 的 dump-info | **在读取大 core 之前，文件名已经降级** |
| 15:18:47.730870 | 写 pod-info | core 写入步骤之后 |
| 15:18:47.731638 | `Failed to get pod id` | 空对象没有 sandbox ID，结束后续补充 |

15:04:38 的另一条 core 记录出现相同链路。原日志前部的 2026-06-09 searchnode/distributor 业务日志属于更早采集内容，不能当作这次 DRS 事件的直接原因。

### 14.3 跨 namespace 同名为何触发

16:00:43 的事后查询，在同一节点看到两个候选：

| namespace | Pod name | 状态 |
| --- | --- | --- |
| `deep-vespa-search-guide-us` | `services-drs-2-0` | `SANDBOX_READY` |
| `deep-vespa-opa-algo-us` | `services-drs-2-0` | `SANDBOX_READY` |

短 hostname 只有一段，代码得到的 namespace 线索为 `""`。它无法匹配这两个正常 namespace，报错后返回空对象，再回退成 unknown。

**结论不是“查不到完整 Pod 名”，而是“查到了多个候选，却缺乏可靠身份来选中一个”。** Kubernetes 允许不同 namespace 使用同名 Pod；问题在采集器把 hostname 当作足够的身份线索。

边界：故障时的错误结合代码能证明当时进入多候选未匹配分支；16:00 快照展示具体同名对象，但不是 15:18 的完整历史候选快照。**现有证据不能确定这个 core 属于上述哪个 namespace。**

### 14.4 为什么还有 core，却没有完整元数据

<!-- source: core-dump-composer/src/main.rs:79:86 -->
```rust
    let pod_object = match cli.pod(&cc.params.hostname) {
        Ok(v) => v,
        Err(e) => {
            error!("{}", e);
            // We fall through here as the coredump and info can still be captured.
            json!({})
        }
    };
```

<!-- source: core-dump-composer/src/main.rs:107:115 -->
```rust
    let namespace = pod_object["metadata"]["namespace"]
        .as_str()
        .unwrap_or("unknown");

    cc.set_namespace(namespace.to_string());

    let podname = pod_object["metadata"]["name"].as_str().unwrap_or("unknown");

    cc.set_podname(podname.to_string());
```

这是有意保留 core 的降级行为。随后代码发现没有 sandbox ID，调用 `zip.finish()` 后退出，不继续收集 runtime、容器、镜像和业务日志。

本例归档目录显示 ZIP 只有 `.core`、`dump-info.json`、`pod-info.json` 三个条目，pod-info 为 `{}`。这与代码路径一致，但仍不等于做过 core 内容完整性检验。

## 15. Pod 重启、PID 变化与正确修复方向

### 15.1 先分清是哪种“重启”

| 场景 | 主要变化 | 对采集的意义 |
| --- | --- | --- |
| 同一 Pod 内容器重启 | Pod UID 通常不变，新 container ID、新进程 | 不能拿新容器元数据替代旧容器 |
| Pod 删除后重建 | 名字可能相同，但 UID 不同 | 名称相同不表示同一实例 |
| 子进程崩溃，容器主进程仍存活 | 容器不一定重启 | 一个 core 不一定对应一次 Pod 重启 |
| 节点上的 handler 尚在工作 | 旧进程的退出/回收可能延后 | 非零 core_pipe_limit 的等待机制有帮助 |

Pod 对象生命周期与容器重启的区别见 [Kubernetes Pod 生命周期](https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/)；旧容器回收机制见 [Kubernetes 垃圾回收](https://kubernetes.io/docs/concepts/architecture/garbage-collection/)。

内核传给这一轮 handler 的参数不会因为后来重启就自动变成新 PID。新进程可以有新的 PID；旧 PID 也可能在更晚时被复用，因此不能隔很久只靠数字重新猜身份。

正常主进程退出和容器重启的先后关系还受 core dump 等待影响，不能简单断言“打包一开始，原容器就必然已经重启”。强制删除、其他进程变化、runtime 清理和采集超时仍需分别考虑。

### 15.2 这次 unknown 不是“打包后 PID 变了”

当前实现根本没有用 PID 去做最初的 Pod 选择；它用 hostname。现场时间线也显示，unknown 在 core 主体写入之前已经确定。

所以重启竞态是值得修复的另一个风险，**不能替换已经由证据确认的本次多候选根因**。

### 15.3 推荐设计：精确身份，尽早快照

下面是**尚未实施的设计建议**：

```text
内核通过新增参数传 %P（宿主机 PID）
  -> cdc 尽早读取 /proc/<host_pid>/cgroup
  -> 解析 container ID，必要时提取 Pod UID 线索
  -> 精确匹配 runtime 容器记录（包括已退出容器）
  -> 获得对应 podSandboxId
  -> 保存 namespace / name / UID / sandbox ID /
     container ID / imageRef / 身份来源 / 采集时间
  -> 开始大 core 的流式接收与压缩
  -> 后续以已有快照完成归档
```

`/proc/<pid>/cgroup` 描述进程的 cgroup 成员关系；实际路径格式取决于 cgroup v1/v2、systemd/cgroupfs 和 runtime。[proc_pid_cgroup(5)](https://man7.org/linux/man-pages/man5/proc_pid_cgroup.5.html)

身份字段需要**完整快照**。只先记下 container ID，等几十秒后再查 namespace，仍然可能遇到 runtime 记录已经被清理。

### 15.4 修复时必须守住的边界

- 保留现有 `%p` 与文件名 pid 语义，另加 `host_pid`，不要直接把 8588 当成节点 PID。
- 先取真实节点 cgroup 样本，不能凭一个正则假定所有环境格式一致。
- 查容器时包括已退出实例；当前 libcrio 的 `ps` 调用没有 `-a`，有遗漏崩溃实例的风险。
- 准确绑定后记录 UID；不能按同名新 Pod 重新绑定。
- 不取候选第一条，不按“最新创建”猜，不只筛 READY。本例两个都 READY。
- 元数据查询必须有短超时；失败时保留 core 和已知身份线索，并记录失败阶段，不无限阻塞内核管道。
- `core_pipe_limit` 对 `/proc` 的等待保证，不保护 CRI 元数据免于 GC。
- 归属信息与辅助日志可以不同策略：身份尽早快照；日志获取允许失败，但不能改换身份。

**潜在 breaking change：** 若把新的 `--host-pid` 参数设为必填，Agent 的 pattern、cdc CLI、手工调用与测试必须同步迁移。若保持可选，也要明确缺失时是“未知归属”，而不是恢复不可靠猜测。当前尚未实施任何这类变更。

### 15.5 建议的回归用例

跨 namespace 同名、两个 READY、无 namespace 后缀、同名重建但 UID 改变、容器已退出、CRI 查询超时、cgroup 解析失败、v1/v2 与 systemd/cgroupfs 样本、core 保留但归属失败、压缩超时后的不完整包处理。

测试应先让已知错误稳定复现，再改代码；优先断言“core 绑定到正确实例或明确未知”“失败仍可保留 core”，而不是锁死内部函数调用顺序。

## 16. 排查时按阶段找证据

### 16.1 先定位节点和时间

下面的 `NODE_NAME`、`HANDLER_POD`、`FULL_SANDBOX_ID`、`HOST_PID` 都是需先核实再填入的占位变量。普通 `kubectl` 命令表示语义；生产环境应使用组织批准的 Viewer/PAM 入口。

```bash
# 执行位置：有授权的运维终端。只读。
kubectl get pods -n core-dump-handler -o wide

kubectl get pods -n core-dump-handler \
  -l name=core-dump-ds \
  --field-selector "spec.nodeName=${NODE_NAME}" -o wide

kubectl logs -n core-dump-handler "${HANDLER_POD}" \
  -c coredump-container --timestamps --since=2h
```

查的是产生 core 的那个节点上的 handler，不是随便找一个同名 DaemonSet Pod。保存精确时间及其时区。

### 16.2 Agent Pod 中可以看什么

```bash
# 执行位置：有授权的运维终端。读取指定 Pod 内文件。
kubectl exec -n core-dump-handler "${HANDLER_POD}" \
  -c coredump-container -- \
  tail -n 300 /data/core-dump-handler/composer.log

kubectl get pod -n core-dump-handler "${HANDLER_POD}" \
  -o jsonpath='{.status.containerStatuses[*].imageID}'

kubectl get pvc -n core-dump-handler -o wide
```

第二条读取实际 imageID，比只看 DaemonSet 模板中的 tag 更接近运行实物。若 Composer 日志为空，先检查 cdc 实际路径与挂载对应关系，不要先认定“没有发生 core”。

### 16.3 节点上需要核对什么

```bash
# 执行位置：故障节点的授权只读会话。
sysctl kernel.core_pattern kernel.core_pipe_limit fs.suid_dumpable
ls -l /data/core-dump-handler/cdc
sha256sum /data/core-dump-handler/cdc
file /data/core-dump-handler/cdc
df -h /data/core-dump-handler/cores
df -i /data/core-dump-handler/cores
ls -l /run/containerd/containerd.sock

/data/core-dump-handler/crictl \
  -c /data/core-dump-handler/crictl.yaml \
  pods --name services-drs-2-0 -o json
```

如果需要沿已确认身份继续查：

```bash
# 仍在故障节点；使用完整、已核实 ID。
/data/core-dump-handler/crictl \
  -c /data/core-dump-handler/crictl.yaml \
  inspectp "${FULL_SANDBOX_ID}"

/data/core-dump-handler/crictl \
  -c /data/core-dump-handler/crictl.yaml \
  ps -a -p "${FULL_SANDBOX_ID}" -o json

# HOST_PID 必须来自可靠的节点 PID 证据，不是直接使用文件名的 %p。
cat "/proc/${HOST_PID}/cgroup"
```

PID 已退出后路径可能不存在；事后读到的同号新进程也不能证明旧 core 的归属。进一步读取 `journalctl` 或内核日志时，应限定节点和时间窗，不要把历史日志混入本次因果链。

### 16.4 故障定位表

| 现象 | 优先看 | 需要避免的误判 |
| --- | --- | --- |
| 完全没有 cdc 日志 | 实际 pattern、二进制可执行性、触发信号、dumpable、权限/LSM、pipe limit | 只看 handler Pod Ready |
| `failed to find pod` | 原 hostname、候选数、namespace 选择代码 | 直接归因网络或 RBAC |
| `stderr not empty` | crictl stderr、退出码、配置和版本 | 当前 wrapper 把任意 stderr 判错，warning 也可能触发 |
| core 有，JSON 少 | 首个错误、失败发生在 core 前还是后 | 把所有缺失都称为压缩失败 |
| ZIP 解不开 | 解压器支持、timeout、磁盘、ZIP 收尾 | 把不支持 Zstd 当成损坏 |
| 本地有 ZIP、S3 没有 | Agent 日志、S3/网络、锁、inotify 重试 | 以 Composer 完成为上传完成 |
| 通知有、对象下载不到 | 上传链路与 key 映射 | 以 webhook 成功为持久化证明 |
| 参数改了不生效 | OnDelete、实际 Pod 镜像、节点文件与 sysctl | 只检查 Helm values |

`sweep` 是一次写入远端并可能删除本地文件的动作；应在保留故障证据、确认目标 bucket 后受控执行，不属于本节只读采集命令。

## 17. 安全实验与拿到 core 后怎么分析

### 17.1 三层验证，从小到大

1. **文档/静态层**：检查源码、参数、模板渲染。不会证明真实 core 采集成功。
2. **Composer 模拟层**：已有 mock core 经 stdin 输入，验证 ZIP 内容和错误路径。不涉及真实内核崩溃。
3. **隔离节点端到端层**：经过批准，在专用测试 VM 或测试节点上部署并触发一个小进程崩溃，验证完整链路。

不要把生产业务 Pod 当测试靶子，也不要在未隔离的共享节点随意覆盖 `core_pattern`。普通容器共享节点内核，“只是起个测试容器”不等于没有节点级影响。

### 17.2 一个最小崩溃程序长什么样

这是教学用 C 源码，不会在本文生成过程中执行：

```c
#include <stdlib.h>

int main(void) {
    abort();
}
```

仅在已经批准、配置完成的隔离 Linux 测试环境中，用带符号的二进制运行：

```bash
# 执行位置：隔离测试环境。运行最后一行会主动崩溃。
cc -g -O0 crash-demo.c -o crash-demo
./crash-demo
```

如果直接在宿主机测试，它验证的是内核与保存链路，不会天然得到 Kubernetes Pod 身份。要验证 Pod 归属，需要把测试程序放入受控测试 Pod，并记录它的 namespace、UID、container ID 和所在节点作为期望值。

### 17.3 什么叫端到端验收通过

- 记录测试进程与 Pod 实例的预期身份。
- Composer 日志中能找到这一轮参数和完成过程，没有归属错误。
- ZIP 的 namespace/Pod UID/container 身份与预期一致。
- ZIP 可用支持该压缩格式的工具检验，并能读取目标条目。
- GDB 能用匹配的程序识别 core，得到合理的线程与调用栈。
- S3 实际对象可读取，核对大小/校验和；不是只看通知或上传状态行。
- 本地文件清理、失败保留、重试行为符合预期。

### 17.4 下载后先检查，避免一下展开几十 GiB

```bash
# 执行位置：有足够空间的离线分析机。
# 使用支持 ZIP/Zstd 的 7-Zip；不同系统可执行名可能是 7zz 或 7z。
7zz l crash.zip

# 会遍历压缩内容，可能很耗 CPU/I/O；先评估体积和资源。
7zz t crash.zip
```

先列目录与大小，再决定是否解压巨大 core。不要对不可信压缩包盲目解压到重要目录；应使用独立、受限的分析目录。压缩包测试通过只能说明归档结构和校验通过，不能单独证明原始 core 覆盖了所需内存。

### 17.5 GDB 需要与崩溃现场匹配的材料

至少准备：

- 对应崩溃版本、架构的业务可执行文件。
- 对应共享库与运行时 rootfs。
- 调试符号或匹配的 debug symbol 文件。
- 目标 core；尽量保留镜像 digest、build ID、源码提交。

示例：

```text
gdb /analysis/exact-build/vespa-drsd-bin /analysis/crash.core

(gdb) set sysroot /analysis/matching-rootfs
(gdb) info threads
(gdb) thread apply all bt
(gdb) frame 0
(gdb) info locals
```

`thread apply all bt` 查看各线程调用栈。必要时用 `bt full` 获取更多信息，但输出可能包含敏感数据。[GDB Backtrace](https://sourceware.org/gdb/current/onlinedocs/gdb.html/Backtrace.html)、[GDB Files](https://sourceware.org/gdb/current/onlinedocs/gdb.html/Files.html)

`image-info.json` 提供寻找镜像的线索，不自动提供匹配的可执行文件；不能随便拿“最新版本”二进制分析旧 core。信号 6 常让调用栈顶部停在 abort 路径，还要往上追导致 abort 的业务调用。

## 18. 容易记错的地方与术语表

### 18.1 十条最值得记住的边界

1. Linux 生成 core，cdc 接收；Agent 不负责把活进程内存主动 dump 出来。
2. handler Pod 正常，不等于宿主机 cdc 可执行。
3. Kubernetes namespace、Linux namespace 是不同层面的概念。
4. Pod 名不是全局唯一身份；UID、sandbox ID、container ID 不能互换。
5. `%p` 不是可靠的宿主机 PID，JSON 名字 `real_pid` 不会改变它的来源。
6. 找不到 Pod 信息不必等于 core 丢失；本工程有保留 core 的降级路径。
7. 文件关闭、ZIP 完成、通知、远端持久化是不同状态。
8. 压缩率很高不自动说明损坏，也不自动说明完整。
9. 配置模板改了不等于节点已生效；OnDelete 尤其需要验证实际 Pod。
10. README、测试和构建脚本可能过时；最终以指定版本代码、运行证据和官方机制交叉判断。

### 18.2 术语速查

| 术语 | 通俗解释 |
| --- | --- |
| core dump | 进程异常时导出的可分析状态 |
| stdin | 进程的标准输入，本工程通过它接收内核字节流 |
| core_pattern | 节点告诉内核“core 应该交给谁”的配置 |
| sysctl | 读取/设置内核运行参数的接口 |
| PID namespace | 决定进程看到哪些 PID、编号如何呈现 |
| UTS namespace | 隔离 hostname 等标识的 Linux 机制 |
| cgroup | 为进程分组并实施资源管理的机制 |
| Pod namespace | Kubernetes 对象的命名范围，不是 Linux PID namespace |
| Pod UID | 一次 Kubernetes Pod 对象的唯一身份 |
| sandbox | runtime 为 Pod 维护的基础运行环境实例 |
| CRI / crictl | 容器运行时接口 / 对应命令行工具 |
| inotify | Linux 文件系统事件通知机制 |
| advisory file lock | 需要参与者配合遵守的文件锁 |
| ZIP64 / Zstandard | 大 ZIP 的扩展机制 / 本工程采用的压缩算法 |
| S3 key | 对象存储中对象的名字，不一定是本地路径 |
| Cargo workspace | 一起管理多个 Rust package 的工作区 |
| Helm Chart | 可带参数渲染出 Kubernetes 清单的部署模板包 |

### 18.3 适合后续从哪里动手

先做不会改动生产行为的任务：补齐 `COMP_*` 的实际作用说明；为跨 namespace 同名归属错误补回归测试；为打包阶段增加清晰、可关联 UUID 的诊断字段。

需要重点审查的模块是身份选择、节点 sysctl 安装/恢复、ZIP 完整性、S3 上传成功判定。不要把它们当普通字符串重构来做。

## 19. 源码与官方资料索引

### 19.1 本地源码

以下行号以 `4d18c34` 为准；后续修改代码后行号可能移动。

| 完整路径 | 关键位置 |
| --- | --- |
| `/Users/liwu.xing/core-dump-handler/core-dump-agent/src/main.rs` | 44～152 初始化；224～284 inotify；289～348 上传；420～500 配置；552～588 remove |
| `/Users/liwu.xing/core-dump-handler/core-dump-composer/src/main.rs` | 26～43 超时；79～115 身份；117～180 ZIP/core；217～225 缺 ID；230～367 补充信息；369～385 通知 |
| `/Users/liwu.xing/core-dump-handler/core-dump-composer/src/config.rs` | `CoreConfig::new`、`get_dump_info`、模板与 CLI 定义 |
| `/Users/liwu.xing/core-dump-handler/core-dump-composer/src/logging.rs` | 14～24 日志位置与 FileAppender |
| `/Users/liwu.xing/core-dump-handler/core-dump-composer/src/events.rs` | `CoreEvent`、`write_event` |
| `/Users/liwu.xing/core-dump-handler/vendor/libcrio/src/lib.rs` | 94～115 选 Pod；158～163 容器列表；316～370 命令错误处理 |
| `/Users/liwu.xing/core-dump-handler/vendor/rust-s3-0.31.0/src/bucket.rs` | 51 分块大小；850～923 multipart 路径 |
| `/Users/liwu.xing/core-dump-handler/vendor/rust-s3-0.31.0/src/request.rs` | HTTP 状态与 `fail-on-err` |
| `/Users/liwu.xing/core-dump-handler/Dockerfile` | UBI7/UBI8 多阶段构建 |
| `/Users/liwu.xing/core-dump-handler/musl.Dockerfile` | 旧 musl 构建分支 |
| `/Users/liwu.xing/core-dump-handler/build-docker-image.sh` | 标签、推送、本地镜像删除 |
| `/Users/liwu.xing/core-dump-handler/.gitlab-ci.yml` | 内部构建和签名流程 |
| `/Users/liwu.xing/core-dump-handler/Cargo.toml` | workspace、release profile、S3 patch |
| `/Users/liwu.xing/core-dump-handler/charts/core-dump-handler/values.yaml` | Chart 默认值，不等于现场实际值 |
| `/Users/liwu.xing/core-dump-handler/charts/core-dump-handler/templates/daemonset.yaml` | 环境变量、权限、生命周期与挂载 |
| `/Users/liwu.xing/core-dump-handler/charts/core-dump-handler/templates/_helpers.tpl` | 共享卷挂载及传播设置 |
| `/Users/liwu.xing/core-dump-handler/core-dump-composer/README.md` | 测试目录和单线程要求 |

### 19.2 外部资料

正文已在相关原理旁提供链接。重点阅读 Linux `core(5)`、内核 sysctl 文档、Kubernetes 的 crictl/Pod 生命周期文档，以及 Docker/Cargo/GDB 官方手册。

外部文档核对日期为 2026-10-22；它们说明通用机制，不替代对目标节点内核、容器运行时和 CLI 版本的核实。特别是 CRI API 的 master 页面、Rust stable 文档会随版本变化。

## 20. 后续补充区

### 20.1 尚待收集的现场信息

- [ ] 实际节点 `kernel.core_pattern`、`kernel.core_pipe_limit`、`fs.suid_dumpable`。
- [ ] 运行中 Agent 的 imageID/digest 与节点 cdc 的 SHA-256。
- [ ] 对应节点 containerd、crictl、内核、cgroup 驱动和 v1/v2 信息。
- [ ] 真实业务进程的 host PID 与 cgroup 样本。
- [ ] 故障时间点的准确 namespace/Pod UID/container ID 身份证据。
- [ ] ZIP 完整性、core 可分析性和业务崩溃原因。
- [ ] 大文件 multipart 上传与本地删除的故障注入验证。
- [ ] 当前构建环境的可复现性、Rust 测试实际结果和 Chart 兼容性。

### 20.2 学习记录

| 日期 | 学到的概念 / 做过的验证 | 证据位置 | 仍不确定的问题 |
| --- | --- | --- | --- |
| 2026-10-22 | 源码梳理与 unknown 根因复盘；尚未实施修复 | 本文、evidence、专项报告 | 见上方清单 |
| 待补充 |  |  |  |

### 20.3 后续修改记录

| 日期 | 改动 | 验证结果 | 是否涉及 breaking change |
| --- | --- | --- | --- |
| 待补充 |  |  |  |

更新 HTML 的命令如下，会读取本 Markdown 并覆盖同目录 `reports/engineering-guide.html`，不触碰原专项报告：

```bash
cd /Users/liwu.xing/工作积累/k8s/core-dump-handler
uv run --with markdown-it-py python scripts/render_html.py
```

**本次结论：unknown 的已确认原因是 hostname 多候选归属失败；“host PID 精确定位 + 大 core 打包前元数据快照”是后续修复方向，尚未落地。**
