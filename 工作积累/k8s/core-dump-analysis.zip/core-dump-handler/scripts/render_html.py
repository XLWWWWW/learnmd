"""Render the maintained learning notes as a standalone, offline HTML document."""

from __future__ import annotations

import hashlib
import html
import re
from pathlib import Path

from markdown_it import MarkdownIt

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "README.md"
OUTPUT = ROOT / "reports" / "engineering-guide.html"

STYLE = """
:root {
  color-scheme: light;
  --ink: #252b2b;
  --muted: #606c6b;
  --accent: #126b60;
  --link: #225b99;
  --line: #dbe2df;
  --paper: #fff;
  --soft: #f3f6f4;
}
* { box-sizing: border-box; letter-spacing: 0; }
html { scroll-padding-top: 24px; }
body {
  margin: 0; background: var(--paper); color: var(--ink);
  font: 16px/1.85 -apple-system, BlinkMacSystemFont, "PingFang SC",
    "Noto Sans CJK SC", "Microsoft YaHei", sans-serif;
}
a { color: var(--link); text-underline-offset: 3px; overflow-wrap: anywhere; }
a:hover { color: var(--accent); }
a:focus-visible, summary:focus-visible { outline: 3px solid #bd671e; outline-offset: 3px; }
.page { display: grid; grid-template-columns: 256px minmax(0, 1fr); }
.sidebar {
  position: sticky; top: 0; height: 100vh; overflow-y: auto;
  background: var(--soft); border-right: 1px solid var(--line);
  padding: 28px 22px 30px;
}
.identity { font-size: 16px; font-weight: 750; line-height: 1.5; overflow-wrap: anywhere; }
.edition { color: var(--muted); font-size: 12px; margin: 9px 0 24px; }
.sidebar nav { display: grid; gap: 3px; }
.sidebar nav a {
  display: block; border-left: 2px solid transparent; padding: 6px 0 6px 10px;
  font-size: 13px; line-height: 1.65; color: #465352; text-decoration: none;
}
.sidebar nav a:hover { color: var(--accent); border-left-color: var(--accent); }
.mobile-contents { display: none; }
main { min-width: 0; padding: 40px 48px 96px; }
article { max-width: 980px; margin: 0 auto; }
.kicker { margin: 0 0 10px; color: var(--accent); font-size: 12px; font-weight: 750; }
h1 { font-size: 34px; line-height: 1.45; margin: 0 0 24px; overflow-wrap: anywhere; }
h2 {
  font-size: 25px; line-height: 1.5; margin: 64px 0 24px;
  padding-top: 20px; border-top: 2px solid var(--accent); overflow-wrap: anywhere;
}
h3 { font-size: 19px; line-height: 1.55; margin: 32px 0 14px; overflow-wrap: anywhere; }
p { margin: 14px 0; overflow-wrap: anywhere; }
li { padding-left: 3px; margin: 7px 0; overflow-wrap: anywhere; }
ul, ol { padding-left: 24px; }
strong { font-weight: 720; }
blockquote {
  margin: 22px 0; padding: 4px 20px; border-left: 4px solid #b96b36;
  background: #faf6f2; color: #414442;
}
pre {
  background: #f5f7f8; color: #23343c; border: 1px solid #dce3e6;
  border-radius: 4px; padding: 18px 20px; margin: 20px 0;
  white-space: pre-wrap; overflow-wrap: anywhere; word-break: break-word;
  font: 12.5px/1.8 "SFMono-Regular", Consolas, "Liberation Mono", monospace;
  tab-size: 4; max-width: 100%;
}
code {
  font-family: "SFMono-Regular", Consolas, "Liberation Mono", monospace;
  font-size: .88em; overflow-wrap: anywhere; background: #f0f3f2;
  padding: 1px 4px; border-radius: 3px;
}
pre code { font: inherit; background: transparent; padding: 0; border-radius: 0; }
.table-wrap { overflow-x: auto; width: 100%; margin: 22px 0; }
table { width: 100%; border-collapse: collapse; font-size: 14px; }
th, td { text-align: left; padding: 12px 14px; border-bottom: 1px solid var(--line); vertical-align: top; overflow-wrap: anywhere; }
th { background: #edf3f0; font-weight: 700; border-top: 1px solid var(--line); }
tr:nth-child(even) td { background: #fafbfa; }
th:first-child, td:first-child { padding-left: 12px; }
.source-caption { color: var(--muted); font-size: 11px; margin: 20px 0 -12px; overflow-wrap: anywhere; }
details { margin: 20px 0; border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); padding: 12px 0; }
summary { cursor: pointer; font-size: 14px; font-weight: 650; color: var(--accent); }
.diagram { margin: 26px 0; background: #f6f8f7; padding: 24px 18px; border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); }
.diagram-flow { display: grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap: 0; }
.diagram-stage { border-left: 3px solid #126b60; padding: 0 14px; min-width: 0; }
.diagram-stage:nth-child(2) { border-left-color: #bd671e; }
.diagram-stage:nth-child(3) { border-left-color: #225b99; }
.diagram-stage b { display: block; font-size: 15px; line-height: 1.6; }
.diagram-stage span { display: block; font-size: 12px; line-height: 1.8; color: var(--muted); margin-top: 7px; overflow-wrap: anywhere; }
figcaption { color: var(--muted); font-size: 12px; margin-top: 18px; }
.doc-footer { margin-top: 60px; padding-top: 20px; border-top: 1px solid var(--line); font-size: 12px; color: var(--muted); overflow-wrap: anywhere; }
@media (min-width: 1600px) { main { padding-left: 72px; padding-right: 72px; } }
@media (max-width: 1024px) {
  .page { grid-template-columns: 210px minmax(0,1fr); }
  .sidebar { padding: 24px 14px; }
  main { padding: 32px 28px 64px; }
  h1 { font-size: 29px; }
  .diagram-flow { grid-template-columns: 1fr; gap: 22px; }
}
@media (max-width: 740px) {
  .page { display: block; }
  .sidebar { position: static; height: auto; padding: 20px; border-right: 0; border-bottom: 1px solid var(--line); }
  .edition { margin-bottom: 0; }
  .sidebar > nav { display: none; }
  .mobile-contents { display: block; margin: 14px 0 0; padding-bottom: 0; border-bottom: 0; }
  .mobile-contents nav { margin-top: 12px; }
  main { padding: 28px 20px 56px; }
  h1 { font-size: 27px; }
  h2 { font-size: 22px; margin-top: 46px; }
  h3 { font-size: 18px; }
  table { font-size: 12px; }
  th, td { padding: 10px 8px; }
  pre { padding: 14px 12px; font-size: 11px; }
  blockquote { padding-left: 13px; padding-right: 10px; }
}
@media print {
  @page { size: A4; margin: 15mm; }
  body { font-size: 10.5pt; line-height: 1.65; }
  .page { display: block; }
  .sidebar { display: none; }
  main { padding: 0; }
  h1 { font-size: 25pt; }
  h2 { font-size: 17pt; margin-top: 28px; break-after: avoid; }
  h3 { font-size: 13pt; break-after: avoid; }
  p, li { orphans: 3; widows: 3; }
  table { font-size: 9pt; }
  .table-wrap { overflow: visible; }
  thead { display: table-header-group; }
  tr { break-inside: avoid; }
  pre { font-size: 8pt; border-color: #bbb; }
  a { color: inherit; }
  .diagram { break-inside: avoid; }
  .diagram-flow { grid-template-columns: repeat(3,minmax(0,1fr)); }
}
"""

DIAGRAM = """
<figure class="diagram" aria-label="工程运行位置与职责">
  <div class="diagram-flow">
    <div class="diagram-stage">
      <b>1. Kubernetes / Agent</b>
      <span>DaemonSet 部署常驻 Agent<br>复制 cdc、写配置、设置 sysctl<br>监听 ZIP 并负责 S3 上传</span>
    </div>
    <div class="diagram-stage">
      <b>2. 节点内核 / Composer</b>
      <span>业务进程崩溃触发内核<br>内核将 core 写入 cdc 的 stdin<br>查询 CRI，写出 ZIP</span>
    </div>
    <div class="diagram-stage">
      <b>3. 对象存储 / 分析</b>
      <span>Agent 上传已有 ZIP<br>开发者获取匹配程序与符号<br>离线使用 GDB 分析</span>
    </div>
  </div>
  <figcaption>core 的触发、打包与上传由不同执行主体完成；各阶段需要独立验证。</figcaption>
</figure>
"""


def main() -> None:
    text = SOURCE.read_text(encoding="utf-8")
    md = MarkdownIt("commonmark", {"html": True}).enable("table")
    tokens = md.parse(text)
    toc = []
    section_count = 0
    subsection_count = 0
    for index, token in enumerate(tokens):
        if token.type == "heading_open":
            title = tokens[index + 1].content
            if token.tag == "h2":
                anchor = f"chapter-{section_count}"
                section_count += 1
                subsection_count = 0
                toc.append((anchor, title))
            elif token.tag == "h3":
                subsection_count += 1
                anchor = f"chapter-{section_count - 1}-{subsection_count}"
            else:
                anchor = "title"
            token.attrSet("id", anchor)

    def table_open(*_args):
        return '<div class="table-wrap"><table>\n'

    def table_close(*_args):
        return "</table></div>\n"

    md.renderer.rules["table_open"] = table_open
    md.renderer.rules["table_close"] = table_close
    default_fence = md.renderer.rules["fence"]

    def render_fence(items, index, options, env):
        result = default_fence(items, index, options, env)
        if items[index].info.strip() == "mermaid":
            return (
                DIAGRAM
                + '<details class="diagram-source"><summary>模块依赖图：Mermaid 源码</summary>'
                + result
                + "</details>"
            )
        return result

    md.renderer.rules["fence"] = render_fence
    original_html_block = md.renderer.rules.get("html_block")

    def render_html_block(items, index, options, env):
        content = items[index].content
        source = re.fullmatch(r"<!-- source: (.+):(\d+):(\d+) -->\s*", content)
        if source:
            path, first, last = source.groups()
            return (
                '<p class="source-caption" data-source="'
                + html.escape(path, quote=True)
                + f'" data-start="{first}" data-end="{last}">'
                + "源码 · /Users/liwu.xing/core-dump-handler/"
                + html.escape(path)
                + f" · L{first}–L{last} · 4d18c34</p>\n"
            )
        if original_html_block:
            return original_html_block(items, index, options, env)
        return content

    md.renderer.rules["html_block"] = render_html_block
    body = md.renderer.render(tokens, md.options, {})
    nav = "\n".join(
        f'<a href="#{anchor}">{html.escape(title)}</a>' for anchor, title in toc
    )
    digest = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    document = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="core-dump-handler 工程学习、Linux core 机制、构建部署与 unknown 故障排查笔记。">
<title>core-dump-handler · 工程学习与故障排查笔记</title>
<style>{STYLE}</style>
</head>
<body>
<div class="page">
<aside class="sidebar">
  <div class="identity">core-dump-handler</div>
  <p class="edition">工程学习笔记<br>2026-10-22 · 源码 4d18c34</p>
  <nav aria-label="章节目录">{nav}</nav>
  <details class="mobile-contents">
    <summary>章节目录</summary><nav aria-label="移动端章节目录">{nav}</nav>
  </details>
</aside>
<main><article>
<p class="kicker">ENGINEERING NOTES / LINUX · RUST · KUBERNETES</p>
{body}
<footer class="doc-footer">
维护源：README.md<br>
源文档 SHA-256：{digest}<br>
范围：源码与已提供证据分析；不代表编译、部署或生产验证完成。
</footer>
</article></main>
</div>
</body></html>
"""
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(document, encoding="utf-8")
    print(f"Rendered {section_count} chapters: {OUTPUT}")


if __name__ == "__main__":
    main()
