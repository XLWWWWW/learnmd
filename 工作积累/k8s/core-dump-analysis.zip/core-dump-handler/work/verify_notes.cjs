const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");
const { pathToFileURL } = require("node:url");
const { createHash } = require("node:crypto");
const { chromium } = require(
  "/Users/liwu.xing/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright",
);

const root = path.resolve(__dirname, "..");
const report = path.join(root, "reports", "engineering-guide.html");
const revision = "4d18c344dd04532019769a82321a9a60c34a8ed0";
const repository = "/Users/liwu.xing/core-dump-handler";

async function main() {
  const browser = await chromium.launch({
    executablePath: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    headless: true,
  });
  try {
    const context = await browser.newContext({ offline: true });
    const page = await context.newPage();
    const errors = [];
    const requests = [];
    page.on("pageerror", (error) => errors.push(error.message));
    page.on("request", (request) => requests.push(request.url()));
    await page.goto(pathToFileURL(report).href);
    await page.evaluate(() => document.fonts.ready);
    const structure = await page.evaluate(() => {
      const ids = [...document.querySelectorAll("[id]")].map((node) => node.id);
      return {
        language: document.documentElement.lang,
        title: document.title,
        ids,
        sections: [...document.querySelectorAll("h2")].map((node) => node.textContent),
        missingTargets: [...document.querySelectorAll('a[href^="#"]')]
          .map((node) => node.getAttribute("href").slice(1))
          .filter((id) => !ids.includes(id)),
        assetCount: document.querySelectorAll("[src], link[href]").length,
        scriptCount: document.scripts.length,
        footer: document.querySelector("footer").textContent,
        sources: [...document.querySelectorAll(".source-caption")].map((node) => ({
          source: node.dataset.source,
          start: Number(node.dataset.start),
          end: Number(node.dataset.end),
          text: node.nextElementSibling.textContent,
        })),
      };
    });
    assert.equal(structure.language, "zh-CN");
    assert.equal(structure.sections.length, 21);
    assert.equal(new Set(structure.ids).size, structure.ids.length);
    assert.deepEqual(structure.missingTargets, []);
    assert.equal(structure.assetCount, 0);
    assert.equal(structure.scriptCount, 0);
    assert.equal(structure.sources.length, 6);
    for (const source of structure.sources) {
      const original = execFileSync(
        "git", ["-C", repository, "show", `${revision}:${source.source}`],
        { encoding: "utf8" },
      ).split("\n");
      assert.equal(
        source.text,
        original.slice(source.start - 1, source.end).join("\n") + "\n",
        source.source,
      );
    }
    const digest = createHash("sha256").update(fs.readFileSync(path.join(root, "README.md"))).digest("hex");
    assert(structure.footer.includes(digest));
    const viewports = [];
    for (const width of [1440, 1024, 768, 390, 320]) {
      await page.setViewportSize({ width, height: width < 741 ? 844 : 1000 });
      await page.evaluate(() => window.scrollTo(0, 0));
      const checks = await page.evaluate(() => ({
        width: document.documentElement.clientWidth,
        scrollWidth: document.documentElement.scrollWidth,
        codeOverflow: [...document.querySelectorAll("pre")]
          .filter((node) => node.scrollWidth > node.clientWidth + 1).length,
        articleWidth: document.querySelector("article").getBoundingClientRect().width,
        rightOverflow: [...document.querySelectorAll("h1,h2,h3,p,pre,figure")]
          .filter((node) => node.getBoundingClientRect().right > innerWidth + 1).length,
      }));
      assert(checks.scrollWidth <= checks.width, `page overflow at ${width}`);
      assert.equal(checks.codeOverflow, 0, `code overflow at ${width}`);
      assert.equal(checks.rightOverflow, 0, `content overflow at ${width}`);
      viewports.push(checks);
      if (width === 1440 || width === 390) {
        await page.screenshot({ path: path.join(__dirname, `guide-${width}-top.png`) });
        await page.locator("#chapter-5").scrollIntoViewIfNeeded();
        await page.screenshot({ path: path.join(__dirname, `guide-${width}-linux.png`) });
        await page.locator(".diagram").scrollIntoViewIfNeeded();
        await page.screenshot({ path: path.join(__dirname, `guide-${width}-diagram.png`) });
        await page.locator("#chapter-14").scrollIntoViewIfNeeded();
        await page.screenshot({ path: path.join(__dirname, `guide-${width}-case.png`) });
      }
    }
    await page.setViewportSize({ width: 1440, height: 1000 });
    await page.locator('.sidebar > nav a[href="#chapter-15"]').click();
    assert.equal(new URL(page.url()).hash, "#chapter-15");
    await page.locator(".diagram-source > summary").click();
    assert.equal(await page.locator(".diagram-source").getAttribute("open"), "");
    await page.setViewportSize({ width: 390, height: 844 });
    await page.locator(".mobile-contents > summary").click();
    await page.locator('.mobile-contents a[href="#chapter-14"]').click();
    assert.equal(new URL(page.url()).hash, "#chapter-14");
    await page.emulateMedia({ media: "print" });
    assert.equal(await page.locator(".sidebar").evaluate((node) => getComputedStyle(node).display), "none");
    assert.deepEqual(errors, []);
    assert(requests.every((url) => url.startsWith("file:")));
    const result = {
      title: structure.title,
      chapters: structure.sections.length,
      sourceSnippetsVerified: structure.sources.length,
      markdownSha256: digest,
      offline: true,
      browserErrors: errors,
      viewports,
      internalNavigation: "passed",
      disclosure: "passed",
      printStyles: "checked",
      boundaries: "Document validation only; not application or production testing.",
    };
    fs.writeFileSync(path.join(__dirname, "validation.json"), JSON.stringify(result, null, 2) + "\n");
    console.log(JSON.stringify(result, null, 2));
  } finally {
    await browser.close();
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
